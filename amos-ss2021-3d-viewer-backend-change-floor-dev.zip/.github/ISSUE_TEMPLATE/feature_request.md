---
name: Feature request
about: Suggest new feature (using user story)
---

## User story
1. As a {}
2. I want / need {}
3. So that {}

## Acceptance criteria
* Criterion 1
* Criterion 2
* ...

## Definition of done
* Added only after week 5
* The same for all features
