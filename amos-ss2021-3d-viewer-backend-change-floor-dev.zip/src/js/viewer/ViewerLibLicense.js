"use strict";

export class ViewerLibLicense{
    constructor(name,text){
        this.name = name; //Name of the license
        this.text = text; // Text of the license
    }

}