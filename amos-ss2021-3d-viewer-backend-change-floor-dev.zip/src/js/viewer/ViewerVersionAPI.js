
export class ViewerVersionAPI{

    constructor(MAJOR, MINOR, [vvfov, vvlatov,vvlonov]){
    this.MAJOR=MAJOR;
    this.MINOR=MINOR;
    this.viewer= [vvfov, vvlatov,vvlonov];
        }
    }
