# Deliverables Folder  of 3D Viewer


Deliverables that are uploadable files (e.g. PDFs, your logo, but not your code) go in this folder

Please prefix every files with the delivery date using the ISO norm for dates, which is 20xy-mm-dd.

