"use strict";

export class ViewerWindow{
    // viewerAsync ( baseUrl, callback){}

}